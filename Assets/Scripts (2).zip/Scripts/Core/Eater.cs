using UnityEngine;

namespace QiuQiu
{
    // SizeController.TryEat decide who eat who.
    // This component only decides WHEN the bite happens: a small overlap is not enough,
    // the prey has to be covered by the bigger ball first (Agar.io style).
    [DisallowMultipleComponent]
    [RequireComponent(typeof(SizeController))]
    public class Eater : MonoBehaviour
    {
        // 0 = touch is enough, 1 = the prey's centre must be inside the eater (Agar.io rule)
        [SerializeField, Range(0f, 1f)] private float swallowDepth = 1f;

        private SizeController self;

        private void Awake()
        {
            self = GetComponent<SizeController>();
        }

        private void OnTriggerEnter2D(Collider2D other)
        {
            TrySwallow(other);
        }

        // Enter only fires once, but the overlap keeps growing while the balls sit on each
        // other, so the bite has to be re-checked every physics step.
        private void OnTriggerStay2D(Collider2D other)
        {
            TrySwallow(other);
        }

        private void TrySwallow(Collider2D other)
        {
            if (other == null)
            {
                return;
            }

            SizeController target = other.GetComponentInParent<SizeController>();
            if (target == null || target == self)
            {
                return;
            }

            if (self.IsDead || target.IsDead)
            {
                return;
            }

            if (self.Team == Team.Player && target.Team == Team.Player)
            {
                return;
            }

            if (!IsCovered(target))
            {
                return;
            }

            if (!self.TryEat(target))
            {
                return;
            }

            // only the player hears its own bite, ten AI eating must stay silent
            if (self.Team == Team.Player && AudioManager.Instance != null)
            {
                AudioManager.Instance.PlayEatEnemy();
            }
        }

        private bool IsCovered(SizeController target)
        {
            if (!self.CanEat(target))
            {
                return false;
            }

            // Allowed centre distance. depth 1 -> target centre inside the eater (Agar.io),
            // depth 0 -> the target has to be completely swallowed.
            float allowed = self.Radius - (1f - swallowDepth) * target.Radius;
            if (allowed <= 0f)
            {
                return false;
            }

            Vector2 offset = (Vector2)target.transform.position - (Vector2)transform.position;
            return offset.sqrMagnitude <= allowed * allowed;
        }
    }
}
