﻿using UnityEngine;

namespace QiuQiu
{
    // Drives one sub ball of the player.
    //
    // There is no real "main ball" here: every cell steers towards the same aim the player
    // gives, so the whole group flies together at the same speed. What a split piece adds on
    // top of that is a small local offset from the big ball:
    //
    //   split  ->  the piece slides out of its parent and ends up right beside it
    //   drift  ->  both halves keep the same speed, the offset is only nudged gently back
    //   rest   ->  it sits beside the big ball (centre distance = r1 + r2)
    //   merge  ->  PlayerMerge animates the swallow once the cooldown is over
    //
    // The correction works on the offset, not on the absolute velocity, so the piece never
    // gets a speed of its own and never lags behind when the player moves.
    public class PlayerSubBall : MonoBehaviour
    {
        [Header("Offset spring")]
        [Tooltip("How hard the piece is nudged back beside the big ball. Higher = closes the gap faster")]
        [SerializeField] private float homeStrength = 2.5f;

        [Tooltip("How quickly the piece answers to that nudge. Higher = snappier, no overshoot")]
        [SerializeField] private float homeDamping = 4f;

        [Tooltip("Speed cap for the closing motion itself, not counting the player's own movement")]
        [SerializeField] private float maxDriftSpeed = 6f;

        [Header("Follow")]
        [Tooltip("Only used when there is no leader to sit beside (it was eaten this frame)")]
        [SerializeField] private float followAcceleration = 30f;

        private PlayerController leaderController;
        private SizeController self;
        private Rigidbody2D rb;

        public void Initialize(PlayerController controller, float slotAngleDegrees)
        {
            leaderController = controller;
        }

        // The component is added at runtime, so the values live on PlayerController and are
        // pushed down here every frame. That keeps everything tunable from one Inspector.
        public void ApplyTuning(float strength, float damping, float maxDrift, float followAccel)
        {
            homeStrength = strength;
            homeDamping = damping;
            maxDriftSpeed = maxDrift;
            followAcceleration = followAccel;
        }

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            self = GetComponent<SizeController>();
        }

        private void FixedUpdate()
        {
            if (self == null || self.IsDead)
            {
                return;
            }

            // a piece that is still sliding out of its parent is driven by SplitEject
            if (self.IsEjecting)
            {
                return;
            }

            // no controller means nobody drives this ball any more, so leave it alone
            if (leaderController == null)
            {
                leaderController = PlayerController.Active;
                if (leaderController == null)
                {
                    return;
                }
            }

            // the merge pull owns the ball while it is being swallowed
            if (leaderController.IsMerging(self))
            {
                return;
            }

            Vector2 inputVelocity = leaderController.InputVelocity;
            SizeController leader = leaderController.MainBall;

            if (leader == null || leader == self)
            {
                FollowInput(inputVelocity);
                return;
            }

            GlideBesideLeader(leader, inputVelocity);
        }

        // Same speed as the group, plus a gentle nudge back to the resting spot beside the big
        // ball. No throw, no overshoot: it just closes the leftover gap over a second or so.
        private void GlideBesideLeader(SizeController leader, Vector2 inputVelocity)
        {
            Vector2 leaderPosition = leader.transform.position;
            Vector2 offset = rb.position - leaderPosition;
            float restDistance = leader.Radius + self.Radius;

            Vector2 direction = offset.sqrMagnitude > 0.0001f ? offset.normalized : Vector2.zero;
            if (direction == Vector2.zero)
            {
                // exactly on top of the leader: step out to the side we are already drifting to
                Vector2 drifting = rb.linearVelocity - inputVelocity;
                direction = drifting.sqrMagnitude > 0.0001f ? drifting.normalized : Vector2.right;
            }

            Vector2 restingSpot = direction * restDistance;
            Vector2 closing = (restingSpot - offset) * homeStrength;
            if (closing.sqrMagnitude > maxDriftSpeed * maxDriftSpeed)
            {
                closing = Vector2.ClampMagnitude(closing, maxDriftSpeed);
            }

            Vector2 desired = inputVelocity + closing;
            float t = 1f - Mathf.Exp(-Mathf.Max(0.01f, homeDamping) * Time.fixedDeltaTime);
            rb.linearVelocity = Vector2.Lerp(rb.linearVelocity, desired, t);

            Constrain();
        }

        // fallback: no leader to sit beside, just move like everybody else
        private void FollowInput(Vector2 inputVelocity)
        {
            rb.linearVelocity = Vector2.MoveTowards(
                rb.linearVelocity,
                inputVelocity,
                followAcceleration * Time.fixedDeltaTime);

            Constrain();
        }

        // no wall colliders, the arena edge is a soft clamp
        private void Constrain()
        {
            if (ArenaManager.Instance != null)
            {
                ArenaManager.Instance.Constrain(rb, self.Radius);
            }
        }
    }
}
