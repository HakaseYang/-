using UnityEngine;

namespace QiuQiu
{
    // A freshly split piece does NOT appear on the rim: it starts inside the parent, small,
    // then slides out while it grows to full size. That is what makes a split look like the
    // body pushing a piece out of itself instead of a second ball popping into place.
    public class SplitEject : MonoBehaviour
    {
        private SizeController size;
        private Rigidbody2D body;
        private SpriteRenderer shell;

        private Vector2 from;
        private Vector2 to;
        private float duration = 0.3f;
        private float launchSpeed;
        private float startRadius;
        private float endRadius;
        private float elapsed;
        private bool running;

        // origin: centre of the parent cell, target: where the two halves end up touching
        public void Begin(Vector3 origin, Vector3 target, float time, float speed)
        {
            size = GetComponent<SizeController>();
            body = GetComponent<Rigidbody2D>();
            shell = GetComponent<SpriteRenderer>();

            from = origin;
            to = target;
            duration = Mathf.Max(0.01f, time);
            launchSpeed = speed;
            endRadius = size != null ? size.Radius : 0.5f;
            startRadius = endRadius * 0.2f;
            elapsed = 0f;
            running = true;

            if (size != null)
            {
                size.SuppressVisual = true;   // this component owns the scale while it runs
                size.IsEjecting = true;
                size.SetInvulnerable(duration + 0.1f);   // nothing can eat it mid-slide
            }

            if (body != null)
            {
                body.bodyType = RigidbodyType2D.Kinematic;
                body.position = from;
                body.linearVelocity = Vector2.zero;
            }

            Apply(0f);
        }

        private void FixedUpdate()
        {
            if (!running)
            {
                return;
            }

            elapsed += Time.fixedDeltaTime;
            float t = Mathf.Clamp01(elapsed / duration);
            Apply(t);

            if (t >= 1f)
            {
                Finish();
            }
        }

        private void Apply(float t)
        {
            float eased = t * t * (3f - 2f * t);   // smoothstep: starts and stops gently

            if (body != null)
            {
                body.MovePosition(Vector2.Lerp(from, to, eased));
            }

            float radius = Mathf.Lerp(startRadius, endRadius, eased);
            transform.localScale = new Vector3(radius * 2f, radius * 2f, 1f);

            // grow through the same size->order rule, so the piece is never drawn on top of
            // a bigger cell while it is still small
            if (shell != null)
            {
                shell.sortingOrder = SizeController.SortingOrderForRadius(radius);
            }
        }

        private void Finish()
        {
            running = false;

            if (body != null)
            {
                body.bodyType = RigidbodyType2D.Dynamic;
                body.position = to;

                Vector2 dir = to - from;
                dir = dir.sqrMagnitude > 0.0001f ? dir.normalized : Vector2.right;
                body.linearVelocity = dir * launchSpeed;   // the launch speed only kicks in at the end
            }

            if (size != null)
            {
                size.IsEjecting = false;
                size.SuppressVisual = false;
                size.ApplySizeNow();
            }

            Destroy(this);
        }
    }
}
